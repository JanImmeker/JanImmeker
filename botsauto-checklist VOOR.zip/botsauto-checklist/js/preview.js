jQuery(function($){
  var modal='<div id="botsauto-preview-container" style="display:none">'+
    '<div id="botsauto-preview-toolbar" style="margin-bottom:8px;text-align:right">'+
    '<button class="button botsauto-size" data-w="1200">Desktop</button> '+
    '<button class="button botsauto-size" data-w="768">Tablet</button> '+
    '<button class="button botsauto-size" data-w="375">Smartphone</button>'+
    '</div><div id="botsauto-preview-content" style="overflow:auto;margin:0 auto;max-width:1200px"></div></div>';
  $('body').append(modal);

  function adjustTB(){
    var $tb=$('#TB_window');
    if(!$tb.length) return;
    var w=$(window).width();
    var h=$(window).height();
    $tb.css({width:w+'px',height:h+'px',left:0,top:0,marginLeft:0,marginTop:0});
    $('#TB_ajaxContent').css({width:'100%',height:(h-45)+'px'}); // 45px approx thickbox title
  }

  $('#botsauto-preview-btn').on('click',function(e){
    e.preventDefault();
    var id=$(this).data('id');
    var nonce=$(this).data('nonce');
    tb_show('Preview','#TB_inline?inlineId=botsauto-preview-container');
    adjustTB();
    $(window).on('resize.botsauto',adjustTB);
    $('#botsauto-preview-content').html('Loading...');
    $.post(ajaxurl,{action:'botsauto_preview',id:id,_ajax_nonce:nonce},function(html){
      $('#botsauto-preview-content').html(html);
    });
  });

  $(document).on('tb_unload',function(){
    $(window).off('resize.botsauto');
  });

  $(document).on('click','.botsauto-size',function(){
    var w=$(this).data('w');
    $('#botsauto-preview-content').css('max-width',w+'px');
  });
});