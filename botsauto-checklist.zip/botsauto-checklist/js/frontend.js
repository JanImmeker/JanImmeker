jQuery(function($){
  // Initialize info content visibility and handle toggle
  function linkInfo(details){
    var row = details.closest('.botsauto-question-row');
    var content=row.next('.botsauto-info-content');
    if(!content.length) return;
    content.css({display:details.prop('open')?'block':'none',width:row.outerWidth()});
    details.on('toggle', function(){
      content.css('width',row.outerWidth());
      content.stop(true,true).slideToggle(this.open);
    });
  }
  $('details.botsauto-info').each(function(){
    linkInfo($(this));
  });
  $(document).off('click','.botsauto-info-btn');
  $('body').on('click','summary.botsauto-info-btn',function(e){
    e.preventDefault();
    var d=$(this).closest('details.botsauto-info');
    if(d.attr('open')) d.removeAttr('open');
    else d.attr('open',true);
  });
});